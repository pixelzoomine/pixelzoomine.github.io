#!/usr/bin/env node
import { parseEventLogs } from "viem";

import { clients, txUrl } from "./lib/chain.js";
import { settings, zooAt } from "./lib/contract.js";
import { existsSync, writeFileSync } from "node:fs";

import {
  accountFromEnvKey,
  accountFromKeystore,
  askPassword,
  cleanPrivateKey,
  makeKeystore,
  newPrivateKey,
} from "./lib/keystore.js";
import { envSource, loadEnv } from "./lib/env.js";
import { C, bar, endLine, eth, kv, line, num, rate, secs, short } from "./lib/fmt.js";
import { cores, keccakSane, mine } from "./lib/rig.js";
import { makeJob, verifyNonce } from "./shared/mine.js";
import { noEnd } from "./shared/headstart.js";

/*  PIXEL ZOO from a terminal.

    The same keccak as the contract and as the web page: this is not a different
    game, it is the same one without a browser in the way.  Looking for a nonce
    costs nothing but electricity — only the winning number ever goes on chain,
    and the chain checks exactly one hash.

    Signing, in the order the key is looked for:

        PIXELZOO_PRIVATE_KEY   the environment, or a .env beside this file.
                               Nothing is typed, so `auto` can run to the wallet
                               cap on its own and an agent can drive it with no
                               terminal.  The key is in plain text on the disk:
                               lib/env.js is the honest note about that.
        --keystore file.json   encrypted, password typed by hand, never echoed.
                               Nothing on the disk is enough by itself.
        neither                every read still works and so does `mine` (pass
                               --address 0x…): it prints the nonce for you to
                               send from the web page or from your own wallet.
*/

/*  Read the .env before anything asks process.env a question - the contract
    address, the network and the key all come through it.  ENV remembers where
    each variable came from so a message can name the file without naming the
    value.                                                                     */
const ENV = loadEnv();

const ZERO32 = "0x" + "00".repeat(32);
const MAX256 = 2n ** 256n - 1n;
const PEND = ["nothing", "instant", "ticket"];

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const json = (o) => JSON.stringify(o, (_, x) => (typeof x === "bigint" ? x.toString() : x), 2);

const HELP = `
${C.gold}PIXEL ZOO${C.off}  ·  command line miner

  ${C.b}pixelzoo${C.off} <command> [options]

commands
  status                 the collection and the round, as the contract sees them
  job [0x…]              what a wallet has pending: seed, targets, claims left
  open                   open the current round — anyone can, it is one write
  mine                   look for a nonce and print it        ${C.dim}(no key needed)${C.off}
  submit <nonce> [round] send a nonce you already found              ${C.dim}(signs)${C.off}
  claim                  pay the mint price and take the voucher     ${C.dim}(signs)${C.off}
  reveal [--watch]       open the vouchers whose block landed        ${C.dim}(signs)${C.off}
  auto                   open · mine · submit · claim · reveal       ${C.dim}(signs)${C.off}
  verify [nonce] [0x…]   check this keccak against the known vectors
  keystore new|import    write an encrypted keystore to sign with ${C.dim}(makes a file)${C.off}

keys ${C.dim}(only the commands marked (signs) need one)${C.off}
  PIXELZOO_PRIVATE_KEY   exported, or in a .env beside zoo.js. Nothing is typed,
                         so ${C.b}auto${C.off} runs to the wallet cap on its own. Plain
                         text on a disk: use a wallet holding no more than a mint.
  --keystore <file>      an encrypted keystore instead, password typed by hand.
                         ${C.b}keystore new${C.off} writes one, and nothing on the disk is
                         enough by itself: this is the one for a real wallet.

options
  --address 0x…          mine for this address without holding its key
  --contract 0x…         contract address   ${C.dim}(or PIXELZOO_CONTRACT, or pixelzoo.json)${C.off}
  --network <name>       mainnet | testnet  ${C.dim}(or PIXELZOO_NETWORK)${C.off}
  --rpc <url>            another RPC endpoint ${C.dim}(or PIXELZOO_RPC)${C.off}
  --threads <n>          mining threads     ${C.dim}(default: cores - 1)${C.off}
  --timeout <secs>       give up mining after this long
  --count <n>            vouchers to open with reveal ${C.dim}(default: all that are ready)${C.off}
  --once                 auto: stop after one piece instead of filling the wallet
  --json                 machine-readable output for status, job and mine

${C.dim}a solution belongs to the round whose seed it hashed, and it stays good for
WORK_WINDOW rounds after it — about five minutes.  submit finds that round on
its own; pass it by hand if you would rather say it out loud.${C.off}
`;

//  ── options ───────────────────────────────────────────────────────────────
const TAKES_VALUE = new Set([
  "contract",
  "network",
  "rpc",
  "keystore",
  "threads",
  "address",
  "timeout",
  "count",
]);
const ALIAS = { net: "network", key: "keystore" };

function parse(argv) {
  const flags = {};
  const rest = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) {
      rest.push(a);
      continue;
    }
    const eq = a.indexOf("=");
    const raw = eq < 0 ? a.slice(2) : a.slice(2, eq);
    const key = ALIAS[raw] || raw;
    if (TAKES_VALUE.has(key)) flags[key] = eq < 0 ? argv[++i] : a.slice(eq + 1);
    else flags[key] = true;
  }
  return { cmd: rest.shift(), rest, flags };
}

//  ── what every command starts from ────────────────────────────────────────
async function setup(flags, { signer = false } = {}) {
  const cfg = settings(flags);
  const KEY = "PIXELZOO_PRIVATE_KEY";
  let account = null;

  /*  The keystore wins when both are there: somebody who went to the trouble of
      passing --keystore means it, and a .env left over from an earlier run should
      not quietly sign in its place.  Read commands resolve a key too when one is
      lying around, so `mine` and `job` can work out whose wallet this is with no
      --address.                                                                */
  if (flags.keystore) account = await accountFromKeystore(flags.keystore);
  else if (process.env[KEY]) account = accountFromEnvKey(process.env[KEY], KEY);
  else if (signer) {
    throw new Error(
      "this command signs a transaction, so it needs a key. Two ways in:\n" +
        `  ${KEY}=0x…   in a .env beside zoo.js, or exported - nothing to type\n` +
        "  --keystore <file.json>     encrypted instead, and it asks for the password\n" +
        "  the keystore is the safer one: `pixelzoo keystore new ./key.json` writes it"
    );
  }

  /*  Say whose wallet is about to spend money, and where the key came from - the
      file, never the value.  Only for the commands that sign: a read has no
      business narrating this, and --json has no room for it.                   */
  if (signer && account && !flags.json) {
    const from = flags.keystore ? flags.keystore : envSource(ENV, KEY);
    console.log(`  ${C.dim}signing as ${short(account.address)} · key from ${from}${C.off}`);
  }

  const { chain, pub, wallet } = clients({ network: cfg.network, rpc: cfg.rpc, account });
  return { cfg, chain, pub, wallet, account, zoo: zooAt(cfg.address) };
}

/** Whose mine is this: the loaded key, or an address given by hand. */
function whose(ctx, flags, rest = []) {
  const a = rest[0] || flags.address || ctx.account?.address;
  if (!a) throw new Error("which address? pass --address 0x… or load a key with --keystore");
  return a;
}

const read = (ctx, functionName, args = []) =>
  ctx.pub.readContract({ ...ctx.zoo, functionName, args });

/** The contract's own one-call briefing for a miner. */
async function readJob(ctx, miner) {
  const r = await read(ctx, "job", [miner]);
  return {
    round: r[0],
    seed: r[1],
    tTarget: r[2],
    lTarget: r[3],
    luckyLeft: r[4],
    pendKind: Number(r[5]),
    pendRound: r[6],
    claimsLeft: r[7],
    issued: r[8],
    priceWei: r[9],
  };
}

/*  Is the mine open to this wallet yet?

    `roundsToPublic` is 0 both when no head start was ever opened and when a
    timed one has run out - the same fact either way - so the second read is
    only worth making when the first one says a phase is running.

    It can also come back as a 78-digit number: that is the owner's manual
    phase, which ends when they end it and not at a round (shared/headstart.js).
    `forever` is what says so, and nothing may print `left` while it is true. */
async function headStart(ctx, miner) {
  const left = await read(ctx, "roundsToPublic");
  if (left === 0n) return { left: 0n, forever: false, allowed: true };
  return { left, forever: noEnd(left), allowed: await read(ctx, "whitelisted", [miner]) };
}

/*  How many rounds a solution stays good for.  It is a constant in the
    contract — nobody can shorten it under a miner — so ask once and keep it. */
function workWindow(ctx) {
  return (ctx.window ??= read(ctx, "WORK_WINDOW"));
}

/*  Which round does this nonce belong to?  A solution is the hash of one
    round's seed, so the only honest way to know is to try the seeds that are
    still inside the window and see which one it beats.  Newest first: the hit
    that comes out has the most window left to spend.                         */
async function whichRound(ctx, miner, nonce) {
  const [live, window, tTarget, lTarget] = await Promise.all([
    read(ctx, "currentRound"),
    workWindow(ctx),
    read(ctx, "ticketTarget"),
    read(ctx, "luckyTarget"),
  ]);
  const oldest = live > window ? live - window : 0n;

  for (let r = live; r >= oldest; r--) {
    const seed = await read(ctx, "roundSeed", [r]);
    if (seed === ZERO32) continue;
    const v = verifyNonce(makeJob({ seed, miner, ticketTarget: tTarget, luckyTarget: lTarget }), nonce);
    if (v.valid) return { round: r, seed, live, window, ...v };
  }
  return { round: null, live, window };
}

/*  The newest round still worth hashing when the live one is closed: open, and
    with two rounds of window left — one to finish in, one to send in.        */
async function lastOpenInWindow(ctx, live, window) {
  const span = window > 2n ? window - 2n : 0n;
  const oldest = live > span ? live - span : 0n;

  for (let r = live; r >= oldest; r--) {
    const seed = await read(ctx, "roundSeed", [r]);
    if (seed !== ZERO32) return { round: r, seed };
  }
  return null;
}

//  ── writes ────────────────────────────────────────────────────────────────
/*  Every revert this contract can throw, in plain words.  A bare `WorkTooWeak`
    on the terminal tells you nothing; "that seed, not that one" tells you what
    to do next.                                                               */
const WHY = {
  MintClosed: "the mint is closed right now",
  SoldOut: "all 7,777 vouchers are gone",
  AlreadyHolding: "that wallet already has a solution pending — claim it first",
  WalletCapReached: "that wallet already took its three pieces, and it does not reset",
  RoundNotOpen: "that round has no seed: it is in the future, or nobody opened it",
  RoundAlreadyOpen: "this round is already open, mine straight away",
  WorkTooWeak: "that nonce does not beat the target for the round you sent it for",
  WorkExpired: "that solution is older than the work window — mine again",
  SolutionUsed: "that exact solution was already spent",
  NothingToClaim: "nothing pending: mine and submit a nonce first",
  TicketNotReady: "a ticket matures one round later — wait for the next round",
  WrongPayment: "the value sent has to equal mintPriceWei exactly",
  NothingToReveal: "no voucher has its draw block yet",
  NotOwner: "that call belongs to the contract owner",
  /*  The one revert in this list that is nobody's mistake: the mine is up and
      this wallet simply is not on the list yet.  It ends by itself.           */
  NotOnList: "the whitelist has a head start still running — until it ends, only the list can submit work",
  Frozen: "the contract will not accept that change any more",
  NotReady: "the contract has no provenance hash or no baseURI yet",
  ZeroAddress: "the zero address is not allowed",
};

/** viem buries the custom error a few levels down; dig it out. */
function why(e) {
  const w =
    typeof e?.walk === "function"
      ? e.walk((x) => x?.name === "ContractFunctionRevertedError")
      : null;
  const name = w?.data?.errorName;
  if (!name) return null;
  return WHY[name] ? `${name}: ${WHY[name]}` : name;
}

/*  Simulate, then send.  The simulation costs nothing and it is what turns a
    revert into a sentence before any gas is spent — and it hands back the
    function's return value, which a receipt does not carry.                  */
async function send(ctx, functionName, args = [], value) {
  const { pub, wallet, chain, zoo, account } = ctx;

  let sim;
  try {
    sim = await pub.simulateContract({ ...zoo, functionName, args, value, account });
  } catch (e) {
    throw new Error(why(e) || e.shortMessage || e.message);
  }

  const hash = await wallet.writeContract(sim.request);
  line(`  ${C.dim}${functionName} ${short(hash)} · waiting${C.off}`);
  const receipt = await pub.waitForTransactionReceipt({ hash });
  endLine();
  if (receipt.status !== "success") throw new Error(`${functionName} reverted on chain: ${hash}`);

  console.log(`  ${C.green}✓${C.off} ${functionName}  ${C.dim}${txUrl(chain, hash)}${C.off}`);
  return { receipt, result: sim.result };
}

const evs = (ctx, receipt, eventName) =>
  parseEventLogs({ abi: ctx.cfg.abi, logs: receipt.logs, eventName });

//  ── status ────────────────────────────────────────────────────────────────
const STATUS_KEYS = [
  "mintOpen",
  "totalSupply",
  "vouchersIssued",
  "unrevealed",
  "revealReady",
  "nextReveal",
  "mintPriceWei",
  "currentRound",
  "roundBlocks",
  "roundCap",
  "WORK_WINDOW",
  "diffTicket",
  "difficultyNow",
  "diffFromRound",
  "luckyDivisor",
  "baseURI",
  "finalSupply",
  "publicRound",
  "roundsToPublic",
];

async function cmdStatus(flags) {
  const ctx = await setup(flags);
  const got = await Promise.all(STATUS_KEYS.map((k) => read(ctx, k)));
  const v = Object.fromEntries(STATUS_KEYS.map((k, i) => [k, got[i]]));
  const minted = Number(v.totalSupply);

  if (flags.json) {
    /*  `headStartNoEnd` first, because roundsToPublic under a manual phase is a
        sentinel and not a countdown: anything that reads it as a duration is
        wrong by about nineteen hundred years.                                */
    console.log(
      json({
        chainId: ctx.chain.id,
        contract: ctx.cfg.address,
        headStartNoEnd: noEnd(v.roundsToPublic),
        ...v,
      })
    );
    return;
  }

  console.log(`\n${C.gold}PIXEL ZOO${C.off}  ${C.dim}${ctx.chain.name} · ${ctx.chain.id}${C.off}\n`);
  console.log(
    kv([
      ["contract", ctx.cfg.address],
      ["mint", v.mintOpen ? `${C.green}open${C.off}` : `${C.red}closed${C.off}`],
      /*  finalSupply is 0 while the collection can still grow.  Once it is set
          the mint is shut forever and that number is all there will ever be.  */
      ...(v.finalSupply > 0n
        ? [["supply", `${C.amber}frozen at ${num(v.finalSupply)}${C.off} ${C.dim}· closed for good${C.off}`]]
        : []),
      ["minted", `${num(minted)} ${C.dim}/ 7777${C.off}  ${bar((minted / 7777) * 100)}`],
      ["vouchers", `${num(v.vouchersIssued)} issued ${C.dim}·${C.off} ${num(v.unrevealed)} waiting`],
      [
        "draw",
        v.revealReady
          ? `${C.green}ready${C.off} ${C.dim}(voucher ${num(v.nextReveal)})${C.off}`
          : `${C.dim}nothing ready${C.off}`,
      ],
      ["price", `${eth(v.mintPriceWei)} ETH`],
      /*  Only printed while it matters.  A "head start: none" line on every
          status for the whole life of the collection is noise.                */
      ...(v.roundsToPublic > 0n
        ? [
            [
              "head start",
              noEnd(v.roundsToPublic)
                ? `${C.amber}the whitelist only${C.off} ${C.dim}· no end declared: it runs until the owner opens the mine to everybody${C.off}`
                : `${C.amber}${num(v.roundsToPublic)} rounds left${C.off} ${C.dim}· only the whitelist can mine until round ${num(v.publicRound)}${C.off}`,
            ],
          ]
        : []),
      [
        "round",
        `${num(v.currentRound)} ${C.dim}· ${v.roundBlocks} blocks · ${num(v.roundCap)} instant slots${C.off}`,
      ],
      [
        "work window",
        `${num(v.WORK_WINDOW)} rounds ${C.dim}· a solution mined now still counts at round ${num(v.currentRound + v.WORK_WINDOW)}${C.off}`,
      ],
      [
        "difficulty",
        `${num(v.difficultyNow)} hashes a ticket ${C.dim}· lucky 1 in ${num(v.difficultyNow * v.luckyDivisor)}${C.off}`,
      ],
      /*  Only while one is actually pending.  A retarget starts at a round in
          the future, and everything mined before that round is still judged by
          the number above — so a miner hashing right now needs to see both.   */
      ...(v.diffFromRound > v.currentRound
        ? [
            [
              "retarget",
              `${C.amber}${num(v.diffTicket)} from round ${num(v.diffFromRound)}${C.off} ${C.dim}· work mined before it keeps the number above${C.off}`,
            ],
          ]
        : []),
      ["art", v.baseURI || `${C.dim}not set${C.off}`],
    ])
  );
  console.log();
}

//  ── job ───────────────────────────────────────────────────────────────────
async function cmdJob(flags, rest) {
  const ctx = await setup(flags);
  const miner = whose(ctx, flags, rest);
  const [j, window, hs] = await Promise.all([
    readJob(ctx, miner),
    workWindow(ctx),
    headStart(ctx, miner),
  ]);
  const open = j.seed !== ZERO32;

  if (flags.json) {
    console.log(
      json({
        miner,
        roundOpen: open,
        pend: PEND[j.pendKind],
        window,
        headStartRunning: hs.left > 0n,
        headStartNoEnd: hs.forever,
        headStartRounds: hs.forever ? null : hs.left,
        onList: hs.allowed,
        ...j,
      })
    );
    return;
  }

  const hex = (n) => "0x" + n.toString(16).padStart(64, "0");
  console.log();
  console.log(
    kv([
      ["miner", miner],
      [
        "round",
        `${num(j.round)} ${open ? `${C.green}open${C.off}` : `${C.amber}not open${C.off}`}`,
      ],
      ["seed", open ? short(j.seed) : "—"],
      ["target", `${short(hex(j.tTarget))} ${C.dim}· ~${num(MAX256 / j.tTarget)} hashes${C.off}`],
      ["instant slots", `${num(j.luckyLeft)} ${C.dim}left this round${C.off}`],
      [
        "work window",
        `${num(window)} rounds ${C.dim}· mine now, send it in any time up to round ${num(j.round + window)}${C.off}`,
      ],
      [
        "pending",
        PEND[j.pendKind] + (j.pendKind === 2 ? ` ${C.dim}from round ${num(j.pendRound)}${C.off}` : ""),
      ],
      ["claims left", `${num(j.claimsLeft)} ${C.dim}of 3${C.off}`],
      ["price", `${eth(j.priceWei)} ETH`],
      ...(hs.left > 0n
        ? [
            [
              "head start",
              hs.forever
                ? hs.allowed
                  ? `${C.green}on the list${C.off} ${C.dim}· list-only mining, until the owner opens the mine to everybody${C.off}`
                  : `${C.red}not on the list${C.off} ${C.dim}· list-only mining, and no end is declared${C.off}`
                : hs.allowed
                  ? `${C.green}on the list${C.off} ${C.dim}· ${num(hs.left)} rounds before everybody else can mine${C.off}`
                  : `${C.red}not on the list${C.off} ${C.dim}· ${num(hs.left)} rounds until anybody can mine${C.off}`,
            ],
          ]
        : []),
    ])
  );

  if (j.pendKind === 1) console.log(`\n  ${C.gold}instant${C.off} — pixelzoo claim, right now`);
  else if (j.pendKind === 2) {
    console.log(
      j.round > j.pendRound
        ? `\n  ${C.green}ticket matured${C.off} — pixelzoo claim`
        : `\n  ${C.amber}ticket matures at round ${num(j.pendRound + 1n)}${C.off}`
    );
  }
  console.log();
}

//  ── the hunt ──────────────────────────────────────────────────────────────
/*  A nonce counts for the round whose seed it used, and it keeps counting for
    WORK_WINDOW rounds after that.  So a rollover is not a reason to throw the
    search away: the workers keep the same seed and we only start over when the
    window is down to its last round, which is left free for the transaction
    itself.  While the live round is closed and we have no key to open it with,
    an older seed still inside the window does the job just as well.

    Returns one of: {found, round, deadline, job} · {pending} · {capped} · {timeout}.
*/
async function hunt(ctx, miner, flags) {
  const threads = flags.threads ? Number(flags.threads) : Math.max(1, cores() - 1);
  const until = flags.timeout ? Date.now() + Number(flags.timeout) * 1000 : Infinity;
  const window = await workWindow(ctx);

  for (;;) {
    if (Date.now() > until) return { timeout: true };

    const j = await readJob(ctx, miner);
    if (j.claimsLeft === 0n) return { capped: true };
    if (j.pendKind !== 0) return { pending: j };

    /*  Nothing below this line can work while the mint is shut: submitWork and
        claim both revert MintClosed(), and a solution is only good for
        WORK_WINDOW rounds, so hashing ahead of the opening buys nothing either.
        Worse, openRound() has no such check - it is deliberately open to anyone -
        so the branch further down would happily pay gas to open round after round
        in front of a closed door.  One read, before anything is spent.        */
    if (!(await read(ctx, "mintOpen"))) return { closed: true };

    /*  A TIMED head start is the one closed door worth WAITING at rather than
        returning from: it ends on its own, at a round the contract will name.
        Hashing through it would be work the contract is going to refuse, so the
        rig is not started until the window is over - or until --timeout gives
        up, which is checked at the top of this same loop.

        A manual one is the opposite: it ends when a person decides, which may be
        tomorrow, so waiting at it would be indistinguishable from a hung miner.
        Return and name the door instead.                                      */
    const hs = await headStart(ctx, miner);
    if (!hs.allowed) {
      if (hs.forever) return { notListed: true };
      line(
        `  ${C.amber}the whitelist has the mine${C.off} ${C.dim}· ${num(hs.left)} more ${hs.left === 1n ? "round" : "rounds"} · waiting${C.off}`
      );
      await sleep(5000);
      continue;
    }

    let round = j.round;
    let seed = j.seed;

    if (seed === ZERO32) {
      //  Somebody has to pay for the round to exist.  With a key loaded that
      //  somebody is us; without one we look back, and only wait if the window
      //  holds no open round at all.
      if (ctx.wallet) {
        console.log(`  ${C.dim}round ${num(j.round)} is closed — opening it${C.off}`);
        try {
          await send(ctx, "openRound");
        } catch (e) {
          console.log(`  ${C.dim}${e.message}${C.off}`);
        }
        continue;
      }

      const back = await lastOpenInWindow(ctx, j.round, window);
      if (!back) {
        line(`  ${C.amber}round ${num(j.round)} not open${C.off} ${C.dim}· waiting${C.off}`);
        await sleep(5000);
        continue;
      }
      ({ round, seed } = back);
      console.log(
        `  ${C.dim}round ${num(j.round)} is closed · using round ${num(round)}, still inside the window${C.off}`
      );
    }

    const found = await race(ctx, { round, seed, tTarget: j.tTarget, lTarget: j.lTarget }, miner, threads, until, window);
    endLine();
    if (found) return { found, round, deadline: round + window, job: j };
    if (Date.now() <= until) {
      console.log(`  ${C.dim}round ${num(round)} spent its window — starting again on a fresh seed${C.off}`);
    }
  }
}

/*  Hash until the window is nearly gone.  `dead` is the last round the contract
    still takes this work in, so the workers stop the moment that round starts:
    the whole of it is left for the wallet confirmation, which is the part no
    software gets to hurry.                                                    */
function race(ctx, t, miner, threads, until, window) {
  const dead = t.round + window;

  return new Promise((resolve, reject) => {
    let lever = null;

    const watch = setInterval(async () => {
      if (Date.now() > until) return lever?.stop();
      try {
        if ((await read(ctx, "currentRound")) >= dead) lever?.stop();
      } catch {
        //  An RPC hiccup is no reason to throw away a search in progress.
      }
    }, 4000);

    mine({
      seed: t.seed,
      miner,
      ticketTarget: t.tTarget,
      luckyTarget: t.lTarget,
      threads,
      onStart: (h) => {
        lever = h;
        console.log(
          `  ${C.violet}mining${C.off} round ${num(t.round)} ${C.dim}· ${h.threads} threads · ~${num(MAX256 / t.tTarget)} hashes expected · good until round ${num(dead)}${C.off}`
        );
      },
      onProgress: ({ tried, rate: hs, secs: s }) =>
        line(`  ${num(tried)} hashes ${C.dim}·${C.off} ${rate(hs)} ${C.dim}·${C.off} ${secs(s)}`),
    })
      .then(resolve, reject)
      .finally(() => clearInterval(watch));
  });
}

//  ── mine ──────────────────────────────────────────────────────────────────
async function cmdMine(flags) {
  const ctx = await setup(flags);
  const miner = whose(ctx, flags);
  const r = await hunt(ctx, miner, flags);

  if (r.capped) throw new Error("that wallet already took its three pieces");
  if (r.closed) {
    throw new Error(
      "the mint is closed: the contract refuses work and payment until the owner opens it, " +
        "and a nonce is only good for five rounds, so there is nothing worth hashing yet"
    );
  }
  if (r.notListed) {
    throw new Error(
      "only the whitelist can mine right now, this wallet is not on it, and the phase has no " +
        "declared end — it opens when the owner opens it, so there is nothing to wait for here"
    );
  }
  if (r.pending) {
    throw new Error(
      `that wallet already holds a ${PEND[r.pending.pendKind]} — claim it before mining again`
    );
  }
  if (r.timeout) throw new Error("gave up: --timeout ran out with nothing found");

  const f = r.found;
  if (flags.json) {
    console.log(
      json({
        miner,
        round: r.round,
        deadline: r.deadline,
        nonce: f.nonce,
        hash: f.hash,
        lucky: f.lucky,
        tried: f.tried,
      })
    );
    return;
  }

  console.log(
    `\n  ${C.green}found${C.off} ${
      f.lucky ? `${C.gold}lucky hash — this one mints on the spot${C.off}` : "ticket — claim next round"
    }\n`
  );
  console.log(
    kv([
      ["nonce", String(f.nonce)],
      ["hash", f.hash],
      ["round", num(r.round)],
      ["good until", `round ${num(r.deadline)} ${C.dim}· ${num(r.deadline - r.round)} rounds of window${C.off}`],
      ["tried", `${num(f.tried)} hashes ${C.dim}in ${secs(f.ms / 1000)}${C.off}`],
    ])
  );
  console.log(
    `\n  ${C.dim}send it with${C.off}  pixelzoo submit ${f.nonce} ${r.round} --keystore <file>` +
      `\n  ${C.dim}or paste the nonce into the web page — it stays good until round ${num(r.deadline)}${C.off}\n`
  );
}

//  ── submit ────────────────────────────────────────────────────────────────
async function cmdSubmit(flags, rest) {
  const ctx = await setup(flags, { signer: true });
  if (!rest[0]) throw new Error("which nonce? pixelzoo submit 12345678 [round]");

  const nonce = BigInt(rest[0]);
  if (nonce < 0n || nonce > 0xffffffffffffffffn) throw new Error("a nonce is a uint64");

  /*  The round is not decoration: it names the seed the nonce was hashed
      against.  Given by hand it is used as it is; left out, we look for it in
      the seeds still inside the window, which is cheaper than making the miner
      remember a number.                                                       */
  let round = rest[1] ? BigInt(rest[1]) : null;
  if (round === null) {
    const hit = await whichRound(ctx, ctx.account.address, nonce);
    if (hit.round === null) {
      throw new Error(
        `that nonce beats no seed inside the window (rounds ${num(hit.live - hit.window)}…${num(hit.live)})\n` +
          "  mine again, or name the round yourself: pixelzoo submit <nonce> <round>"
      );
    }
    round = hit.round;
    console.log(
      `  ${C.dim}round ${num(round)} · ${hit.lucky ? "lucky" : "ticket"} · ${short(hit.hash)}${C.off}`
    );
  }

  const { result } = await send(ctx, "submitWork", [nonce, round]);
  console.log(
    result
      ? `  ${C.gold}lucky${C.off} — claim right now: pixelzoo claim`
      : "  ticket accepted — claim next round: pixelzoo claim"
  );
}

//  ── claim ─────────────────────────────────────────────────────────────────
async function cmdClaim(flags) {
  const ctx = await setup(flags, { signer: true });
  const j = await readJob(ctx, ctx.account.address);

  if (j.pendKind === 0) throw new Error("nothing pending: mine and submit a nonce first");
  if (j.pendKind === 2 && j.round <= j.pendRound) {
    throw new Error(
      `the ticket from round ${num(j.pendRound)} matures at round ${num(j.pendRound + 1n)}, ` +
        `and it is round ${num(j.round)} now`
    );
  }

  const { receipt } = await send(ctx, "claim", [], j.priceWei);
  const voucher = evs(ctx, receipt, "Claimed")[0]?.args?.voucher;
  console.log(
    `  ${C.gold}voucher ${voucher ?? "?"}${C.off} paid ${eth(j.priceWei)} ETH ` +
      `${C.dim}· the animal is drawn one block later${C.off}`
  );
  console.log(`  ${C.dim}open it with${C.off}  pixelzoo reveal --keystore <file>`);
}

//  ── reveal ────────────────────────────────────────────────────────────────
/*  Opening vouchers is not a privilege: anybody can push the queue along, which
    is exactly why a voucher can never be held hostage.  The queue is strictly in
    order, so pushing it also opens other people's — that is the deal.

    Always revealNext(n), never revealAllReady(): a draw costs about 62,000 gas
    and a queue of a few hundred would not fit in a block.  --watch keeps going
    batch after batch until the queue is empty.                                */
const REVEAL_BATCH = 80n;

async function cmdReveal(flags) {
  const ctx = await setup(flags, { signer: true });
  const asked = flags.count ? BigInt(flags.count) : null;

  const once = async () => {
    const [waiting, ready] = await Promise.all([read(ctx, "unrevealed"), read(ctx, "revealReady")]);
    if (waiting === 0n) return "done";
    if (!ready) return "wait";

    let count = asked && asked < waiting ? asked : waiting;
    if (count > REVEAL_BATCH) count = REVEAL_BATCH;

    const { receipt } = await send(ctx, "revealNext", [count]);

    for (const l of evs(ctx, receipt, "Revealed")) {
      console.log(
        `  ${C.gold}#${l.args.tokenId}${C.off} ${C.dim}voucher ${l.args.voucher} → ${short(l.args.to)}${C.off}`
      );
    }
    return "opened";
  };

  if (!flags.watch) {
    const r = await once();
    if (r === "done") console.log("  nothing waiting: every voucher is open");
    if (r === "wait") console.log(`  ${C.amber}not yet${C.off} — the next draw block has not landed`);
    if (r === "opened") {
      const left = await read(ctx, "unrevealed");
      if (left > 0n) {
        console.log(`  ${C.dim}${left} still in the queue · run it again, or use --watch${C.off}`);
      }
    }
    return;
  }

  console.log(`  ${C.dim}watching · Ctrl-C to stop${C.off}`);
  for (;;) {
    const r = await once();
    if (r === "done") {
      endLine();
      console.log("  nothing left waiting");
      return;
    }
    if (r === "wait") line(`  ${C.dim}waiting for the draw block…${C.off}`);
    await sleep(6000);
  }
}

//  ── auto ──────────────────────────────────────────────────────────────────
/*  The whole thing unattended: open the round if it is closed, mine, submit,
    pay, and open the voucher.  It stops when the wallet has its three pieces,
    or after one with --once.                                                 */
async function cmdAuto(flags) {
  const ctx = await setup(flags, { signer: true });
  const miner = ctx.account.address;

  for (;;) {
    const r = await hunt(ctx, miner, flags);
    if (r.capped) {
      console.log(`  ${C.dim}wallet full: three pieces, and it does not reset${C.off}`);
      return;
    }
    /*  Same reasoning as the whitelist door below: this one opens when a person
        opens it, so waiting at it is indistinguishable from a hung miner.     */
    if (r.closed) {
      console.log(
        `  ${C.amber}the mint is closed${C.off}\n` +
          `  ${C.dim}work and payment both revert until the owner opens it — nothing to do here yet${C.off}`
      );
      return;
    }
    /*  Not a failure, and not something a loop can outlast: stop cleanly rather
        than spend a night of RPC calls on a door only a person can open.      */
    if (r.notListed) {
      console.log(
        `  ${C.amber}the whitelist has the mine and this wallet is not on it${C.off}\n` +
          `  ${C.dim}no end is declared, so there is nothing to wait out — try again once` +
          ` the owner opens the mine to everybody${C.off}`
      );
      return;
    }
    if (r.timeout) throw new Error("gave up: --timeout ran out with nothing found");

    if (r.found) {
      console.log(
        `  ${C.green}found${C.off} nonce ${r.found.nonce}` +
          `${r.found.lucky ? ` ${C.gold}(lucky)${C.off}` : ""}` +
          ` ${C.dim}after ${num(r.found.tried)} hashes · round ${num(r.round)}${C.off}`
      );
      await send(ctx, "submitWork", [BigInt(r.found.nonce), r.round]);
    }

    //  A ticket cannot be paid until the round it was mined in is over.
    for (;;) {
      const j = await readJob(ctx, miner);
      if (j.pendKind === 0) break; // already claimed, by us or by a second window
      if (j.pendKind === 1 || j.round > j.pendRound) {
        endLine();
        await send(ctx, "claim", [], j.priceWei);
        break;
      }
      line(
        `  ${C.dim}ticket from round ${num(j.pendRound)} · waiting for round ${num(j.pendRound + 1n)}${C.off}`
      );
      await sleep(6000);
    }

    //  Push the queue along.  Ours is at the back of it, so if there is a
    //  crowd ahead the queue is drained in batches until it reaches us.
    try {
      for (let batches = 0; batches < 8; batches++) {
        const waiting = await read(ctx, "unrevealed");
        if (waiting === 0n || !(await read(ctx, "revealReady"))) break;
        await send(ctx, "revealNext", [waiting > REVEAL_BATCH ? REVEAL_BATCH : waiting]);
      }
    } catch (e) {
      console.log(`  ${C.dim}reveal skipped: ${e.message}${C.off}`);
    }

    if (flags.once) return;
  }
}

//  ── verify ────────────────────────────────────────────────────────────────
/*  Two different doubts, one command.  Without arguments: does this machine's
    keccak agree with the three known vectors — because a wrong keccak mines
    beautifully and finds nothing the chain accepts.  With a nonce: which round
    does it belong to, and does the chain hash it to the same 32 bytes.        */
async function cmdVerify(flags, rest) {
  const sane = keccakSane();
  console.log(`  keccak vectors  ${sane ? `${C.green}match${C.off}` : `${C.red}DO NOT MATCH${C.off}`}`);
  if (!sane) throw new Error("this keccak disagrees with the contract's — do not mine with it");
  if (!rest[0]) return;

  const ctx = await setup(flags);
  const miner = whose(ctx, flags, rest.slice(1));
  const nonce = BigInt(rest[0]);
  const j = await readJob(ctx, miner);
  const hit = await whichRound(ctx, miner, nonce);

  //  No round claims it: hash it against the live seed anyway, so the numbers
  //  are on screen instead of a bare "no".
  const round = hit.round ?? j.round;
  const seed = hit.seed ?? j.seed;
  if (seed === ZERO32) {
    throw new Error(`round ${num(j.round)} is not open, so there is no seed to check against`);
  }

  const v =
    hit.round !== null
      ? hit
      : verifyNonce(
          makeJob({ seed, miner, ticketTarget: j.tTarget, luckyTarget: j.lTarget }),
          nonce
        );
  const onChain = await read(ctx, "workHash", [seed, miner, nonce]);
  const left = hit.round !== null ? hit.window - (hit.live - hit.round) : 0n;

  console.log(
    kv([
      ["nonce", rest[0]],
      [
        "round",
        `${num(round)} ${C.dim}· live ${num(j.round)}${C.off}` +
          (hit.round !== null
            ? left > 0n
              ? ` ${C.dim}· ${num(left)} rounds of window left${C.off}`
              : ` ${C.red}· window spent${C.off}`
            : ""),
      ],
      ["local hash", v.hash],
      [
        "chain hash",
        `${onChain === v.hash ? `${C.green}identical${C.off}` : `${C.red}${onChain}${C.off}`}`,
      ],
      [
        "verdict",
        v.valid
          ? v.lucky
            ? `${C.gold}lucky — mints on the spot${C.off}`
            : `${C.green}valid ticket${C.off}`
          : `${C.red}too weak for every open round in the window${C.off}`,
      ],
    ])
  );
}

//  ── open ──────────────────────────────────────────────────────────────────
async function cmdOpen(flags) {
  const ctx = await setup(flags, { signer: true });
  const round = await read(ctx, "currentRound");
  const seed = await read(ctx, "roundSeed", [round]);

  if (seed !== ZERO32) {
    console.log(`  round ${num(round)} is already open ${C.dim}${short(seed)}${C.off}`);
    return;
  }

  const { receipt } = await send(ctx, "openRound");
  const ev = evs(ctx, receipt, "RoundOpened")[0]?.args;
  console.log(
    `  round ${num(ev?.round ?? round)} open ${C.dim}· seed ${short(ev?.seed ?? "")}${C.off}`
  );
}

/*  `keystore new` and `keystore import`: where the file --keystore wants comes
    from.

    Everything else in this CLI could be done with no key at all, and then the
    docs said "sign with --keystore ./key.json" and never said how anybody was
    supposed to end up holding a ./key.json.  The honest answer used to be
    `cast wallet import`, which is installing Foundry to run a 40 kB miner, and
    which writes somewhere else anyway.  Now the miner makes the file itself, in
    the same Web3 Secret Storage V3 format geth and Foundry read.

    The key never touches the terminal on the way in either: `import` reads it
    through the same unechoed prompt as a password, so it is not in the scrollback
    and not in the shell history.  It is never printed back, not even in part.  */
async function cmdKeystore(flags, rest) {
  const mode = (rest[0] || "").toLowerCase();
  if (mode !== "new" && mode !== "import") {
    throw new Error("keystore new <file>   or   keystore import <file>");
  }

  const file = rest[1] || flags.keystore || "key.json";
  if (existsSync(file)) throw new Error(`${file} already exists, and this will not overwrite it`);

  /*  Ask for the key before the password: if the key is malformed the run stops
      here, and nobody has typed a password twice for nothing.                 */
  let pk;
  if (mode === "import") {
    console.log(`  paste the private key of the wallet you want to sign with.`);
    console.log(`  ${C.dim}it is not echoed, it is not stored, and it is not printed back.${C.off}`);
    pk = cleanPrivateKey(await askPassword("  private key: "));
  } else {
    pk = newPrivateKey();
  }

  const pass = await askPassword("  new password: ");
  if (pass.length < 8) throw new Error("at least 8 characters: this is the only thing guarding it");
  if ((await askPassword("  again: ")) !== pass) throw new Error("those two do not match");

  const ks = makeKeystore(pk, pass);
  //  0600 where it means something.  On Windows the bit is decoration, so the
  //  line below is the real protection: the file is encrypted before it lands.
  writeFileSync(file, JSON.stringify(ks, null, 2) + "\n", { mode: 0o600 });

  line();
  kv("address", `0x${ks.address}`);
  kv("keystore", `${file}   ${C.dim}scrypt N=${ks.crypto.kdfparams.n} · aes-128-ctr${C.off}`);
  line();
  if (mode === "new") {
    console.log(`  This wallet is empty. Send it a little ETH for gas and the mint price`);
    console.log(`  before claiming: ${C.dim}pixelzoo status${C.off} prints what one costs.`);
  }
  console.log(`  ${C.b}Nobody can recover this password${C.off}, us included: the key is inside`);
  console.log(`  that file and nothing else knows it. Back the file up, remember the`);
  console.log(`  password, and from now on:`);
  console.log(`\n    ${C.gold}pixelzoo auto --keystore ${file}${C.off}\n`);
}

//  ── the front door ────────────────────────────────────────────────────────
const RUN = {
  status: cmdStatus,
  job: cmdJob,
  open: cmdOpen,
  mine: cmdMine,
  submit: cmdSubmit,
  claim: cmdClaim,
  reveal: cmdReveal,
  auto: cmdAuto,
  verify: cmdVerify,
  keystore: cmdKeystore,
};

const { cmd, rest, flags } = parse(process.argv.slice(2));

/*  Leaving is not just process.exit(): on Windows, pulling the plug while a
    piped stdout still has writes queued aborts inside libuv (async.c:76), which
    turns a perfectly good run into exit code 0xC0000409 — and an agent always
    reads this CLI through a pipe.  So set the code and let the loop drain on its
    own; the rig terminates its own workers, so nothing should be holding it.
    The timer is the last resort if something does, and it is unref'd so it can
    never keep the process alive by itself.                                    */
function leave(code) {
  process.exitCode = code;
  setTimeout(() => process.exit(code), 2000).unref();
}

if (!cmd || cmd === "help" || flags.help) {
  console.log(HELP);
  leave(0);
} else if (!RUN[cmd]) {
  console.error(`${C.red}✗${C.off} no such command: ${cmd}\n  pixelzoo help lists them`);
  leave(2);
} else {
  try {
    await RUN[cmd](flags, rest);
    leave(0);
  } catch (e) {
    endLine();
    console.error(`${C.red}✗${C.off} ${e.message}`);
    leave(1);
  }
}
