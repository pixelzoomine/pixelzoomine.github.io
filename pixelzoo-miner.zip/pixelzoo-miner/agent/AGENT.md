# PIXEL ZOO · agent guide

Two ways for a program to mine this collection. Both use the same keccak as the
contract, and neither needs permission from us.

| | |
|---|---|
| **A terminal** | One archive: `curl -LO https://pixelzoomine.github.io/pixelzoo-miner.tar.gz`, `tar -xf`, `npm install`. Take the `.tar.gz`, not the `.zip` beside it: GNU tar cannot read zip, and that is what `tar` means on Linux. In PowerShell the fetch is `curl.exe -LO …`, because bare `curl` there is `Invoke-WebRequest` and rejects `-LO`. Node, one dependency, no browser, and the contract address already in it. It signs from `PIXELZOO_PRIVATE_KEY` in a `.env` the user writes (nothing typed, so `auto` runs unattended to the wallet cap), or from an encrypted keystore it can also create (`node zoo.js keystore new ./key.json`, password typed by them). Reads need no key at all; mining does, because a solution is hashed against one address — the wallet whose key is loaded is the one that mines, pays and receives, and there is no mining for a wallet the CLI cannot sign for. `auto` finishes each piece before it starts the next: it keeps the voucher, waits for the draw block, sends the reveal and prints `minted #1234` before it looks for another nonce. Full reference in the archive's `README.md`; in the repository the same files are `cli/`. |
| **The open page** | `window.PIXELZOO` — a small stable API the site installs. Reads are free; every write opens the user's wallet. |

The archive carries this guide and the agent skill (`skills/pixelzoo-miner/`)
beside the miner, so an agent that has the download has everything it needs and
nothing to go looking for.

Rules that hold in both: **3 per wallet, forever.** A nonce belongs to the round
whose seed it hashed (a round is 5 blocks, about a minute) and you name that round
when you send it — the contract keeps taking it for `WORK_WINDOW` rounds after
that, five as deployed, so a rollover while you are mining or signing costs
nothing. Mining costs no gas. Paying gives you a *voucher*; which animal it
becomes is decided later, by the hash of a block that did not exist when you paid.

## window.PIXELZOO

Present on every tab of the site once the page has loaded. Bigints come back as
decimal **strings** so `JSON.stringify` never throws. Every write returns
`{ok: true, hash}` or `{ok: false, error}` — it never throws either.

```js
PIXELZOO.version        // 1
PIXELZOO.about          // one paragraph, in English
PIXELZOO.chain          // {id, name, rpc, explorer}
PIXELZOO.contract       // "0x…" (empty string if this build has no address)
PIXELZOO.supply         // 7777
PIXELZOO.PEND           // {NONE: 0, INSTANT: 1, TICKET: 2}
PIXELZOO.gifUrl(id)     // thumbnail URL for a token id
PIXELZOO.pageUrl(id)    // the animated HTML page for a token id
```

### Reads

```js
PIXELZOO.state()
// {mintOpen, finalSupply, minted, remaining, issued, unrevealed, revealReady,
//  nextReveal, price, round, roundBlocks, roundCap, workWindow, difficulty,
//  luckyDivisor, walletCap, baseURI, headStartRunning, headStartNoEnd,
//  headStartRounds}
// finalSupply is "0" while the mint can still grow; anything else is the number
// that exists and will ever exist.

PIXELZOO.job()
// {miner, round, seed, roundOpen, ticketTarget, luckyTarget, luckyLeft,
//  pendKind, pendRound, claimsLeft, price, workWindow, goodUntil,
//  onList, headStartRunning, headStartNoEnd, headStartRounds}
// goodUntil is the last round that still takes work mined against this seed.
// headStartRunning is the gate: true while only the whitelist may submit work.
// headStartNoEnd says which kind of phase it is - true means it ends when the
// team ends it, so headStartRounds is null and there is nothing to wait out.
// headStartRounds is how many rounds a TIMED whitelist phase still has the mine
// to itself, the live one included, and it is "0" both when no head start was
// declared and when the one that was has ended - the same fact either way.
// While headStartRunning is true, submitWork reverts NotOnList for anybody whose
// onList is false, so that is the pair to read BEFORE starting the rig.
// {error: "no wallet connected"} | {error: "no contract data yet"}

PIXELZOO.tokens()       // [Number] — token ids this wallet owns
PIXELZOO.status()       // {running, tried, rate, threads, maxThreads, job, found, broken}
```

`status().job` is the `{round, seed}` the current run is pinned to.
`status().found` is `null` until there is something to send, then
`{nonce, hash, lucky, round, seed}` — the round travels with the solution, which
is what lets you sign it calmly three rounds later. `broken` is a string if the
rig refuses to run — a failed keccak self-test, no worker support — and mining is
pointless until it is `null`.

### Writes and the rig

```js
PIXELZOO.setThreads(n)          // 1..maxThreads, only while stopped; returns the value used
PIXELZOO.start()                // begin searching   → {ok} | {ok:false, error}
PIXELZOO.stop()                 // stop searching
await PIXELZOO.mine({timeoutMs}) // search and wait  → {ok:true, nonce, hash, lucky, round} | {ok:false, error}

await PIXELZOO.openRound()          // wallet: open the round if nobody has
await PIXELZOO.submitNonce(n, round) // wallet: send a solution for the round it was mined for
                                     // no arguments: the one just found, with its own round
await PIXELZOO.claim()              // wallet: pay the mint price, get the voucher
await PIXELZOO.reveal(n)            // wallet: open the draws whose block has landed
```

`mine()` defaults to a 15 minute deadline and polls while the workers grind, so
`await` it rather than looping on `status()`. It starts the rig for you.

### The whole loop

```js
const s = PIXELZOO.state();
if (!s.mintOpen) throw new Error("the mint is closed");

let j = PIXELZOO.job();
if (j.error) throw new Error(j.error);          // connect a wallet first
if (j.claimsLeft === "0") throw new Error("this wallet already took its three");
/*  A TIMED head start is a wait, not a refusal: it ends at a round the contract will
    name, and nothing about the mint changes when it does.  Do not hash through
    it - every solution would come back NotOnList.                             */
if (j.headStartRunning && !j.onList) {
  //  Read the flag, never the number: under a manual phase there is no number.
  throw new Error(
    j.headStartNoEnd
      ? "only the whitelist can mine, this wallet is not on it, and the phase ends when the team ends it"
      : `the whitelist has ${j.headStartRounds} more rounds; this wallet is not on it`
  );
}
if (!j.roundOpen) await PIXELZOO.openRound();   // anyone can, it is one cheap write

if (Number(j.pendKind) === PIXELZOO.PEND.NONE) {
  const found = await PIXELZOO.mine({timeoutMs: 10 * 60 * 1000});
  if (!found.ok) throw new Error(found.error);
  await PIXELZOO.submitNonce();                 // found.nonce, for found.round
}

//  A TICKET matures one round later; an INSTANT can be paid at once.
for (;;) {
  j = PIXELZOO.job();
  if (Number(j.pendKind) === PIXELZOO.PEND.NONE) break;             // already paid
  if (Number(j.pendKind) === PIXELZOO.PEND.INSTANT) { await PIXELZOO.claim(); break; }
  if (Number(j.round) > Number(j.pendRound))      { await PIXELZOO.claim(); break; }
  await new Promise((r) => setTimeout(r, 6000));
}

//  The draw: permissionless, in strict order, and in batches of at most 80
//  because a draw costs ~62,000 gas.  Keep going while the queue is not empty.
while (Number(PIXELZOO.state().unrevealed) > 0) {
  const r = await PIXELZOO.reveal();
  if (!r.ok) break;
}
PIXELZOO.tokens();              // what you own now
```

## Manners

- **Never ask a user for a private key or a seed phrase**, and never accept one
  that is offered. On this page you do not need it: signing goes through their
  wallet. Anything that asks you for a key by any other route is not us.
- In the CLI the key is theirs to install, in one of two files, and you touch
  neither. `PIXELZOO_PRIVATE_KEY` in a `.env` beside `zoo.js` is the unattended
  one — they copy `.env.example`, they paste the key, and after that `node zoo.js
  auto` runs to three pieces asking for nothing. Tell them what that costs: plain
  text on the disk, and the mining wallet is the one the pieces land in, so it
  should hold what three claims cost and no more.
- The encrypted route is `node zoo.js keystore new ./key.json` (a fresh wallet) or
  `keystore import ./key.json` (a key they already hold), then `--keystore`. Those
  read from the tty and refuse a pipe, so **you cannot run them** — print the
  command and let the user type into their own terminal.
- Do not read, print, copy or paste the contents of a `.env` or a keystore, and do
  not put a key in a command line. `zoo.js` names the file it signed from and
  never the value; keep it that way in what you report.
- Reading is free. Every write costs the user gas and pops a wallet window: say
  what you are about to send before you send it.
- Three per wallet is a hard contract rule, not a rate limit to route around.
  Mining for a fourth is wasted electricity.
- A rollover does **not** invalidate a nonce: it belongs to the round it hashed
  and `job().goodUntil` says how long the chain still takes it. Do not restart a
  search because the round changed — restart when the window runs out.
- If nobody has opened the round, opening it is a favour to everyone mining, and
  it costs one small write.

## Failure modes worth recognising

| what you see | what it means |
|---|---|
| `WorkExpired` | that solution is older than `workWindow` rounds — mine again |
| `WorkTooWeak` | the nonce does not beat the target for the round you named |
| `RoundNotOpen` | that round has no seed: it is in the future, or nobody opened it |
| `SolutionUsed` | that exact hash was already spent; mine again |
| `AlreadyHolding` | there is a pending solution — claim it before mining |
| `TicketNotReady` | a ticket needs the next round; wait ~1 minute |
| `WrongPayment` | send exactly `state().price` wei, no more |
| `WalletCapReached` | three already; it never resets |
| `NothingToReveal` | no voucher's draw block has landed yet |
| `NotOnList` | a whitelist head start is running and this wallet is not on it — the only one of these that is a wait rather than a mistake. `job().headStartNoEnd` says whether it ends by itself: if it is `false`, `headStartRounds` is the countdown; if it is `true`, only the team can end it |

The contract's own view `job(address)` is the source of truth for all of this;
`status()` only describes the local rig.
