# PIXEL ZOO · command line miner

The same keccak as the contract and as the web page, without a browser in the
way. Looking for a nonce is free: it costs electricity, not gas. Only the
winning number goes on chain, and the chain checks exactly one hash.

```
npm install            # one dependency: viem
node zoo.js verify     # the keccak vectors, before you trust any of it
node zoo.js help
```

If this arrived as an archive from the site, everything is already in place —
including a `pixelzoo.json` with the live contract, which is why the examples
below get away with naming no address. Fetching it again:

```
curl -LO https://pixelzoomine.github.io/pixelzoo-miner.tar.gz
tar -xf pixelzoo-miner.tar.gz && cd pixelzoo-miner
```

The same tree is also served as `pixelzoo-miner.zip`, for double-clicking. The
command above names the `.tar.gz` on purpose: GNU tar, which is what `tar` means
on Linux and in Git Bash, cannot read a zip at all, while `tar -xf` opens a
`.tar.gz` on Linux, macOS and Windows alike. On Windows the same line works for
either file, because `tar.exe` there is libarchive.

Both archives hold the same tree, and the checksums the site prints
beside them are reproducible: `node scripts/pack_cli.mjs` in the repository pins
every timestamp and mode it stores, so packing the same tree twice gives the same
bytes. The agent skill (`skills/pixelzoo-miner/`) and the browser-API reference
(`agent/AGENT.md`) ride inside.

Node 20 or newer. `npm link` (or `npm i -g .`) puts `pixelzoo` on your PATH;
everything below works either way — `node zoo.js status` is the same command as
`pixelzoo status`.

## Keys: read this part

Two ways to sign, and the difference between them is what happens the day
somebody else can read this folder.

### With a .env, and nothing to type

```
cp .env.example .env          # Windows:  copy .env.example .env
```

One line in it:

```
PIXELZOO_PRIVATE_KEY=0xyour_key_here
```

and from there the mint runs by itself:

```
pixelzoo auto                 # open · mine · submit · claim · reveal, to three
```

`auto` is a loop, not one shot. It opens the round when nobody has, hashes until
it finds a solution, sends it, waits the single round a ticket needs to mature,
pays the mint price, pushes the reveal queue and starts over. It stops when the
contract answers `WalletCapReached`, printing `wallet full: three pieces`. Three
pieces, three claims, and nothing typed after that one line. `--once` if you want
a single piece and your terminal back.

Now the cost of that convenience, plainly. The key sits in a plain text file in a
folder that came out of an archive, so whatever can read the folder owns the
wallet: a backup, a screenshot, a shared machine, a stray `git add .`, a
postinstall script belonging to some unrelated package. And the wallet that mines
is the wallet the pieces are minted to, so a burner does not make it free either
— whatever it minted is sitting behind that same plain text key. Move the pieces
out when the run is done, or use the keystore below.

There is no `--private-key` flag, and that is not an inconsistency: an argument
is in your shell history and in every `ps` that walks past, where a file at least
stays put.

### With an encrypted keystore, one password, the same run

The CLI writes the file itself, so nothing else has to be installed:

```
pixelzoo keystore new ./key.json        # a fresh wallet, made here
pixelzoo keystore import ./key.json     # a key you already have
```

`new` generates the key inside this process and never shows it to you: the only
copy is the encrypted file. `import` reads a key you already hold the same way
the password is read, not echoed and not stored. Both ask for the password twice,
both print the address they ended up with, and neither overwrites a file that is
already there.

```
pixelzoo auto --keystore ./key.json
Keystore password: ▉        # once, at the start; nothing is echoed, nothing is stored
```

After that the run is identical, to the same three pieces. What is different is
that the file on the disk is worth nothing on its own: scrypt at N=262144 over a
password that exists nowhere but in your head. Nobody can recover it, us
included — lose it and the file is noise.

The format is the usual Web3 Secret Storage V3 JSON, so a file from `geth account
new` or `cast wallet import` works here unchanged, and this one works there.
scrypt and pbkdf2 are both read; the MAC is checked before anything is decrypted.
What MetaMask's *export* hands you is a raw hex key rather than this format —
that is what `keystore import` takes, and it is also what goes in the `.env`.

### With no key at all

```
pixelzoo mine --address 0xYourWallet     # finds the nonce, prints it, signs nothing
```

Then send it yourself: `PIXELZOO.submitNonce(nonce, round)` from the site's
console, `submitWork(nonce, round)` from your own wallet or from a block
explorer, or `pixelzoo submit <nonce> [round]` later from a machine that does
have a key. `mine` prints the round it was mined for, and the chain keeps taking
it for five. Your address is hashed into the solution, so a nonce
mined for you is worth nothing to anybody else, which is why handing it over the
terminal is safe.

Every read works with no key at all as well: `status`, `job`, `verify`.

## Pointing it at the contract

First one that turns up wins:

```
--contract 0x…                  the flag
PIXELZOO_CONTRACT=0x…           the environment (the address is not a secret)
./pixelzoo.json                 { "contract": "0x…", "network": "mainnet" }
```

`--network mainnet|testnet` (or `PIXELZOO_NETWORK`) picks the chain — Robinhood
Chain 4663, testnet 46630 — and `--rpc <url>` (or `PIXELZOO_RPC`) overrides the
endpoint if you have your own node.

Any of those three variables can live in the `.env` beside `zoo.js` instead of
being exported, in the same file as the key; `.env.example` has them commented
out. A variable already in your environment always beats the file, so a `.env`
that came with the archive can never quietly redirect a command you meant for
somewhere else.

## Commands

| | |
|---|---|
| `status` | the collection and the round, as the contract sees them |
| `job [0x…]` | one wallet: seed, target, what it has pending, claims left, whether it is on the head-start list |
| `open` | open the current round · anyone can, it is one cheap write |
| `mine` | look for a nonce and print it · **no key needed** |
| `submit <nonce> [round]` | send a nonce you already found · the round is looked up if you leave it out |
| `claim` | pay the mint price and take the voucher |
| `reveal [--watch]` | open the vouchers whose draw block has landed |
| `auto` | open · mine · submit · claim · reveal, unattended |
| `keystore new\|import <file>` | write the encrypted file that signing needs |
| `verify [nonce]` | check this keccak against the three known vectors |

`verify` on its own hashes three fixed vectors and compares them with values
baked into `lib/rig.js`. A wrong keccak mines beautifully and finds nothing the
chain will take, so run it once on a new machine. With a nonce it also asks the
contract for `workHash` and prints both hashes side by side.

## What mining actually looks like

A ticket is one hash in 150,000,000 (`diffTicket`), and a lucky one — mints on
the spot — is one in 900,000,000. Measured on one 20-thread laptop:

```
 1 thread    ≈ 0.65 MH/s       a ticket every ~4 minutes
 4 threads   ≈ 2.4 MH/s        a ticket every ~1 minute
 8 threads   ≈ 4.2 MH/s        a ticket every ~35 seconds
15 threads     1.3 - 5 MH/s    a ticket every 30 s to 2 minutes
```

Extra threads help less than the arithmetic suggests — hyperthreads and
efficiency cores are not whole cores — and the last row is a range because of
heat: the same code that bursts at 5 MH/s settles nearer 1.3 once every core has
been busy for a minute and the laptop starts throttling. A desktop with room to
breathe stays at the top of that range.

Averages are averages, too: the search is memoryless, so a ticket can land in
twenty seconds or take a quarter of an hour, and a long run says nothing about
the next hash.

Threads default to cores − 1, so the machine stays usable. `--threads 4` if you
want more of it back.

A round is five blocks, roughly a minute, and a nonce belongs to the round whose
seed it hashed — but it does **not** die with it. `submitWork` takes the round as
an argument and the contract keeps accepting work for `WORK_WINDOW` rounds after
the one it was mined for (five, so about five minutes). So `mine` does not throw
the search away when the round turns over: the workers keep the seed they started
with, and only when the window is down to its last round — left free for the
transaction itself — does the search start again on a fresh seed. `mine` prints
`good until round N`, and `submit` without a round figures out which seed your
nonce beat.

Each thread searches a disjoint range starting from a random base, because the
contract remembers spent solutions and answers `SolutionUsed` to a repeat.

### If a head start is running

The collection may open with a **whitelist head start**: a number of rounds in
which only listed addresses can submit work. It buys time and nothing else — the
same price, the same odds, the same cap of three.

`status` prints a `head start` line while one is running, and `job` says whether
the address it was given is on the list. `mine` checks before it starts: a wallet
that is not on the list is not put to work on hashes the contract would refuse
with `NotOnList()` — it waits, printing how many rounds are left, and starts
hashing by itself when the window ends. `--timeout` still applies to the wait, so
a run that would rather come back than sit there can say so.

After `submit`, a **ticket** matures one round later and an **instant** can be
claimed at once. `claim` pays and hands you a voucher; the animal is drawn from
the hash of a *later* block, which is why `reveal` is a separate step and why
anybody can push that queue along.

## For agents

`status`, `job` and `mine` take `--json` and print nothing else on stdout:

```
pixelzoo mine --address 0xYou --json --timeout 300
{ "miner": "0x…", "round": "…", "deadline": "…", "nonce": 35407314010,
  "hash": "0x…", "lucky": false, "tried": 2137993 }
```

`round` is the one to pass to `submit`; `deadline` is the last round that still
takes it.

Exit codes: `0` fine, `1` something failed and the reason is on stderr, `2` no
such command. Colour turns itself off when stdout is not a terminal, or with
`NO_COLOR=1`. There is also a browser-side API for agents — see
`agent/AGENT.md` and the **07 CLI** tab on the site, which lists every method and
carries these commands ready to copy.

## Files

```
zoo.js              the commands
lib/rig.js          worker pool: one thread per core, disjoint ranges
lib/rig-worker.js   the hot loop; talks through SharedArrayBuffer, never yields
lib/keystore.js     V3 keystore both ways, password prompt, no env var
lib/contract.js     where the address comes from
lib/chain.js        the two Robinhood networks
lib/fmt.js          terminal formatting
../shared/          keccak and the mining loop, shared with the web page
```

`npm test` runs `../shared/selftest.js`: the keccak vectors, byte for byte.
