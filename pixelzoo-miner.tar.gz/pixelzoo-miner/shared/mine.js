/*  The mining loop, shared by the browser worker and the CLI.

    We are looking for a nonce such that

        uint256( keccak256(seed ‖ miner ‖ nonce) )  <=  ticketTarget

    In practice the first 32 bits of the hash already settle it: only when they
    tie exactly with the top 32 bits of the target do we have to compare the
    whole 256 bits (about once every 4 billion attempts).
*/
import {
  makeTemplate,
  hashTop32,
  digestFrom,
  bytesToHex,
  NONCE_HI_WORD,
  NONCE_LO_WORD,
} from "./keccak.js";

const TWO32 = 4294967296;

/** Prepares everything that does not change during a round. */
export function makeJob({ seed, miner, ticketTarget, luckyTarget }) {
  const t = BigInt(ticketTarget);
  const l = BigInt(luckyTarget);
  return {
    seed,
    miner,
    tmpl: makeTemplate(seed, miner),
    ticketTarget: t,
    luckyTarget: l,
    tTop: Number(t >> 224n),
    lTop: Number(l >> 224n),
  };
}

/** One slice of the search.  Returns the find, or how many attempts it made. */
export function mineChunk(job, startNonce, count, A = new Int32Array(50)) {
  const tTop = job.tTop;
  let n = startNonce;
  for (let i = 0; i < count; i++, n++) {
    const hi = Math.floor(n / TWO32) | 0;
    const lo = n | 0;
    const top = hashTop32(A, job.tmpl, hi, lo);
    if (top > tTop) continue;

    // a candidate: either clearly below, or it has to be read in full
    const h = BigInt(bytesToHex(digestFrom(A)));
    if (h > job.ticketTarget) continue;   // only possible on the top == tTop tie
    return {
      found: { nonce: n, hash: "0x" + h.toString(16).padStart(64, "0"), lucky: h <= job.luckyTarget },
      tried: i + 1,
    };
  }
  return { found: null, tried: count };
}

/** Hashes one specific nonce again and classifies it.  For verifying. */
export function verifyNonce(job, nonce) {
  const A = new Int32Array(50);
  const n = Number(nonce);
  const top = hashTop32(A, job.tmpl, Math.floor(n / TWO32) | 0, n | 0);
  const h = BigInt(bytesToHex(digestFrom(A)));
  return {
    hash: "0x" + h.toString(16).padStart(64, "0"),
    top,
    valid: h <= job.ticketTarget,
    lucky: h <= job.luckyTarget,
  };
}

export { NONCE_HI_WORD, NONCE_LO_WORD };
