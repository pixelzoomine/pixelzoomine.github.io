/*  keccak256 specialised for the PIXEL ZOO preimage.

    The contract does exactly this:

        keccak256( abi.encodePacked(bytes32 seed, address miner, uint64 nonce) )

    That is 32 + 20 + 8 = 60 bytes.  Since 60 < 136 (keccak-256's rate) the
    whole thing fits in ONE block: a single permutation per hash, with no
    absorption loop.  And of those 60 bytes only 8 change from one attempt to
    the next, so the starting state is built once and reused.

    A warning: this implementation is generic and readable on purpose, not a
    hand-unrolled one.  It is checked against `cast keccak` (the same
    implementation the EVM uses) in shared/selftest.js.  If it is ever
    optimised, that test is what decides.
*/
import { keccakF } from "./keccak_f.js";
export { keccakF };

// Round constants, as [low, high] pairs of 32 bits.
const RC = new Int32Array([
  0x00000001 | 0, 0x00000000 | 0, 0x00008082 | 0, 0x00000000 | 0,
  0x0000808a | 0, 0x80000000 | 0, 0x80008000 | 0, 0x80000000 | 0,
  0x0000808b | 0, 0x00000000 | 0, 0x80000001 | 0, 0x00000000 | 0,
  0x80008081 | 0, 0x80000000 | 0, 0x00008009 | 0, 0x80000000 | 0,
  0x0000008a | 0, 0x00000000 | 0, 0x00000088 | 0, 0x00000000 | 0,
  0x80008009 | 0, 0x00000000 | 0, 0x8000000a | 0, 0x00000000 | 0,
  0x8000808b | 0, 0x00000000 | 0, 0x0000008b | 0, 0x80000000 | 0,
  0x00008089 | 0, 0x80000000 | 0, 0x00008003 | 0, 0x80000000 | 0,
  0x00008002 | 0, 0x80000000 | 0, 0x00000080 | 0, 0x80000000 | 0,
  0x0000800a | 0, 0x00000000 | 0, 0x8000000a | 0, 0x80000000 | 0,
  0x80008081 | 0, 0x80000000 | 0, 0x00008080 | 0, 0x80000000 | 0,
  0x80000001 | 0, 0x00000000 | 0, 0x80008008 | 0, 0x80000000 | 0,
]);

// The rho shifts and the pi destinations, flattened by lane i = x + 5y.
const ROT = new Uint8Array(25);
const PI = new Uint8Array(25);
{
  const r = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
  ]; // r[x][y]
  for (let x = 0; x < 5; x++) {
    for (let y = 0; y < 5; y++) {
      ROT[x + 5 * y] = r[x][y];
      PI[x + 5 * y] = y + 5 * ((2 * x + 3 * y) % 5);
    }
  }
}

const C = new Int32Array(10); // theta's columns
const B = new Int32Array(50); // the intermediate state of rho+pi

/*  keccak-f[1600] in place, the generic looped version.  `A` is 25 lanes held
    as [low, high] pairs.

    This is the REFERENCE version: readable, easy to audit, slow.  Mining uses
    `keccakF` from keccak_f.js, which is the same thing unrolled by
    scripts/gen_keccak.py.  selftest.js compares the two against each other,
    and both against `cast keccak`.
*/
export function keccakFGeneric(A) {
  for (let round = 0; round < 24; round++) {
    // theta ─ the parity of each column, mixed into its neighbours
    for (let x = 0; x < 5; x++) {
      const a = 2 * x, b = 2 * (x + 5), c = 2 * (x + 10), d = 2 * (x + 15), e = 2 * (x + 20);
      C[a] = A[a] ^ A[b] ^ A[c] ^ A[d] ^ A[e];
      C[a + 1] = A[a + 1] ^ A[b + 1] ^ A[c + 1] ^ A[d + 1] ^ A[e + 1];
    }
    for (let x = 0; x < 5; x++) {
      const p = 2 * ((x + 4) % 5), n = 2 * ((x + 1) % 5);
      const dLo = C[p] ^ ((C[n] << 1) | (C[n + 1] >>> 31));
      const dHi = C[p + 1] ^ ((C[n + 1] << 1) | (C[n] >>> 31));
      for (let y = 0; y < 5; y++) {
        const i = 2 * (x + 5 * y);
        A[i] ^= dLo;
        A[i + 1] ^= dHi;
      }
    }

    // rho (rotate every lane) + pi (move it somewhere else)
    for (let i = 0; i < 25; i++) {
      const s = ROT[i], j = 2 * PI[i], k = 2 * i;
      const lo = A[k], hi = A[k + 1];
      if (s === 0) {
        B[j] = lo; B[j + 1] = hi;
      } else if (s === 32) {
        B[j] = hi; B[j + 1] = lo;
      } else if (s < 32) {
        B[j] = (lo << s) | (hi >>> (32 - s));
        B[j + 1] = (hi << s) | (lo >>> (32 - s));
      } else {
        const m = s - 32;
        B[j] = (hi << m) | (lo >>> (32 - m));
        B[j + 1] = (lo << m) | (hi >>> (32 - m));
      }
    }

    // chi ─ the only non-linear part
    for (let y = 0; y < 5; y++) {
      const row = 5 * y;
      for (let x = 0; x < 5; x++) {
        const i = 2 * (x + row);
        const n1 = 2 * (((x + 1) % 5) + row);
        const n2 = 2 * (((x + 2) % 5) + row);
        A[i] = B[i] ^ (~B[n1] & B[n2]);
        A[i + 1] = B[i + 1] ^ (~B[n1 + 1] & B[n2 + 1]);
      }
    }

    // iota
    A[0] ^= RC[2 * round];
    A[1] ^= RC[2 * round + 1];
  }
  return A;
}

// ── byte helpers ─────────────────────────────────────────────────────────

const HEX = [];
for (let i = 0; i < 256; i++) HEX.push(i.toString(16).padStart(2, "0"));

export function hexToBytes(hex) {
  const s = hex.startsWith("0x") || hex.startsWith("0X") ? hex.slice(2) : hex;
  if (s.length % 2 !== 0) throw new Error("odd-length hex: " + hex);
  const out = new Uint8Array(s.length / 2);
  for (let i = 0; i < out.length; i++) {
    const b = parseInt(s.substr(2 * i, 2), 16);
    if (Number.isNaN(b)) throw new Error("invalid hex: " + hex);
    out[i] = b;
  }
  return out;
}

export function bytesToHex(bytes) {
  let s = "0x";
  for (let i = 0; i < bytes.length; i++) s += HEX[bytes[i]];
  return s;
}

/** Turns the 4 bytes of a 32-bit word around. */
function bswap32(v) {
  return (
    ((v & 0x000000ff) << 24) |
    ((v & 0x0000ff00) << 8) |
    ((v >>> 8) & 0x0000ff00) |
    ((v >>> 24) & 0x000000ff)
  );
}

// ── the 60-byte preimage ─────────────────────────────────────────────────

/*  How the 60 bytes sit on the lanes (a lane is 8 bytes, little endian inside
    the lane):

        bytes  0..31   seed        lanes 0..3
        bytes 32..51   miner       lanes 4..6 (up to byte 51)
        bytes 52..59   nonce BE    lane 6 (high half) + lane 7 (low half)
        byte  60       0x01        lane 7, high half  ─ keccak's padding
        byte  135      0x80        lane 16, high half ─ end of block

    Which means that between two attempts only TWO 32-bit words change:
    A[13] (lane 6, high) and A[14] (lane 7, low).
*/
export const NONCE_HI_WORD = 13;
export const NONCE_LO_WORD = 14;

/** The starting state, with seed and miner already in and the nonce at zero. */
export function makeTemplate(seedHex, minerHex) {
  const seed = hexToBytes(seedHex);
  const miner = hexToBytes(minerHex);
  if (seed.length !== 32) throw new Error("the seed must be 32 bytes");
  if (miner.length !== 20) throw new Error("the address must be 20 bytes");

  const block = new Uint8Array(136);
  block.set(seed, 0);
  block.set(miner, 32);
  block[60] = 0x01;   // keccak's padding (the original one, the EVM's)
  block[135] = 0x80;  // last bit of the block

  const A = new Int32Array(50);
  for (let b = 0; b < 136; b++) {
    if (block[b] === 0) continue;
    const w = 2 * (b >> 3) + ((b & 7) >> 2);
    A[w] |= block[b] << (8 * (b & 3));
  }
  return A;
}

// ── hashing ──────────────────────────────────────────────────────────────

/*  Leaves the permuted state for that nonce in `A` and returns the TOP 32 bits
    of the hash (its first 4 bytes read as one big number, which is how
    `uint256(h)` reads them in Solidity).  Those 32 bits are enough to throw out
    99.999…% of the attempts; only when they tie with the target does the whole
    hash have to be looked at.
*/
export function hashTop32(A, tmpl, nonceHi, nonceLo) {
  A.set(tmpl);
  A[NONCE_HI_WORD] = bswap32(nonceHi);
  A[NONCE_LO_WORD] = bswap32(nonceLo);
  keccakF(A);
  return bswap32(A[0]) >>> 0;
}

/** The hash's 32 bytes, from a state that has already been permuted. */
export function digestFrom(A) {
  const out = new Uint8Array(32);
  for (let b = 0; b < 32; b++) {
    const w = 2 * (b >> 3) + ((b & 7) >> 2);
    out[b] = (A[w] >>> (8 * (b & 3))) & 0xff;
  }
  return out;
}

/** The whole keccak256(seed ‖ miner ‖ nonce), in hex.  For tests and the CLI. */
export function workHash(seedHex, minerHex, nonce) {
  const tmpl = makeTemplate(seedHex, minerHex);
  const n = BigInt(nonce);
  const A = new Int32Array(50);
  hashTop32(A, tmpl, Number(n >> 32n) | 0, Number(n & 0xffffffffn) | 0);
  return bytesToHex(digestFrom(A));
}

/** The hash as a BigInt, which is what the contract compares. */
export function workHashBig(seedHex, minerHex, nonce) {
  return BigInt(workHash(seedHex, minerHex, nonce));
}

