/*  "Until I say so" — how a head start with no end is written on chain.

    The contract stores one number for this: `publicRound`, the absolute round
    the mine opens to everybody at.  There is no second "the list has it until
    the owner stops it" flag, and adding one would mean two storage slots
    answering the same question, which is how a mint ends up disagreeing with
    itself.  So the sentinel below IS that flag: a round so far away it never
    arrives, and one write to bring it back to 0 when the owner is done.

    Why type(uint256).max, rather than "now plus a million rounds":

      · it reads as *never* to anybody looking at the storage slot, instead of
        as a deadline somebody has to know is fake;
      · once the mint is open, setPublicRound may only ever be brought FORWARD
        (`round_ >= publicRound` reverts) — and every real round is smaller
        than the maximum, so the stop button can always be pressed;
      · nothing in the contract ever ADDS to publicRound.  Its only three uses
        are `live < publicRound`, `publicRound - live` and `round_ >=
        publicRound`, so the largest possible value overflows nothing.

    The cost is that `roundsToPublic()` then answers a 78-digit number.  That is
    not a countdown and must never be shown as one: every reader asks noEnd()
    first and says "no end" instead.  Both halves of the project import this
    file so there is one sentinel and one name for it.
*/

/** publicRound for a phase that only the owner can end. */
export const NO_END = (1n << 256n) - 1n;

/*  Where "a countdown" stops and "never" begins.  A billion rounds is about
    nineteen hundred years; a real head start is minutes.  The threshold is used
    rather than an equality test because the reader is usually holding
    `roundsToPublic` (the sentinel minus the live round) or a float that went
    through Number(), and neither is exactly NO_END.                          */
export const NO_END_FROM = 1e9;

/** Is this `roundsToPublic` / `publicRound` value the no-end phase? */
export function noEnd(v) {
  if (v === undefined || v === null) return false;
  return typeof v === "bigint" ? v >= BigInt(NO_END_FROM) : v >= NO_END_FROM;
}
