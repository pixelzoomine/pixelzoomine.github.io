---
name: pixelzoo-miner
description: Mine and mint PIXEL ZOO — find a proof-of-work nonce, submit it, pay for the voucher and open the draw. Use when the user wants to mine PIXELZOO, check a round, submit a nonce, claim a voucher, reveal a token, or drive the pixelzoo CLI or the site's window.PIXELZOO API.
---

# PIXEL ZOO miner

7,777 animated pixel creatures on Robinhood Chain (mainnet 4663, testnet 46630).
Minting is earned with proof of work: nothing is allocated and nothing is sold on
a list. The collection may open with a whitelist *head start* — a phase in which
only listed addresses can submit work — and that buys time, not better odds. It is
normally **manual**: it lasts until the team opens the mine to everybody, so there
is no countdown to quote. `job` reports both facts. This skill drives either the
command-line miner or the live web page.

## The mechanic, in the order it happens

1. **A round opens.** Rounds are 5 blocks (~1 minute) and anyone can open the
   current one — one cheap write, `openRound()`. Nobody picks the seed.
2. **You mine.** Find a `nonce` with
   `keccak256(seed ‖ your address ‖ nonce) <= ticketTarget`. Free: it costs
   electricity, not gas. Averages one hash in 150,000,000; one in 900,000,000
   is *lucky*. On a laptop that is a minute or so a ticket, and the search is
   memoryless, so it can also be ten. Read `diffTicket` rather than trusting
   this number: the owner can raise it.
3. **You submit it.** `submitWork(nonce, round)` — you name the round whose seed
   you hashed and the chain does one hash. A lucky hash becomes an **INSTANT**, an
   ordinary one a **TICKET**.
4. **You pay.** `claim()` with exactly `mintPriceWei` — read it, never assume it.
   The aim is $0.30, but the contract holds wei and ETH does not hold still, so
   the owner re-pegs the number when the two drift apart; quoting a dollar figure
   from memory is how a caller ends up sending the wrong value and getting
   `WrongPayment`. An INSTANT can be paid at once; a TICKET matures one round
   later. You get a *voucher*, not a drawing.
5. **The draw.** The voucher is decided by the hash of a *later* block, so the
   outcome did not exist when you paid. `revealNext(n)` opens the queue in strict
   order, anyone may call it, and it goes in batches: a draw costs about 62,000
   gas, so a long queue takes more than one transaction.

**Three per wallet, forever.** It never resets. A nonce belongs to the round whose
seed it hashed, and the contract still takes it `WORK_WINDOW` rounds later (five,
about five minutes): a rollover between finding a hash and signing it costs
nothing, so never restart a search just because the round changed.

## Never handle keys

Do not ask the user for a private key or a seed phrase, and do not accept one if
it is offered: there is no place to put it. The CLI signs from an encrypted
keystore file whose password the user types themselves, unechoed; the web page
signs through their wallet. If some path seems to want a raw key, that path is
wrong.

## Path A — the CLI

One archive, 40 kB, and this skill file is inside it — if you are reading this
from `skills/pixelzoo-miner/`, the miner is two directories up and already
pointed at the right contract.

```bash
curl -LO https://pixelzoomine.github.io/pixelzoo-miner.tar.gz
tar -xf pixelzoo-miner.tar.gz && cd pixelzoo-miner
npm install                                 # one dependency: viem
node zoo.js verify                          # keccak vectors must match before mining
node zoo.js status                          # round, price, how many are left
```

Take the `.tar.gz` and not the `.zip` that sits beside it: GNU tar is what `tar`
is on Linux and in most containers, and it cannot read a zip — it answers "This
does not look like a tar archive" and stops. `tar -xf` opens a `.tar.gz`
everywhere, including Windows, whose `tar.exe` is libarchive and reads both.
Working from the repository instead of the download, the same files are in `cli/`
and the commands need `--contract 0x…`.

Address resolution, first hit wins: `--contract 0x…`, then `PIXELZOO_CONTRACT`,
then a `pixelzoo.json` in the working directory — which the archive already
carries, with the live address in it, which is why nothing above names one. Add
`--network testnet` for the test chain and `--rpc <url>` for another endpoint.

**Mine without a key** (safe, signs nothing, prints the nonce):

```bash
node zoo.js mine --address 0xTHEIR_WALLET --json --timeout 600
```

**The whole run, unattended** (asks for the keystore password once):

```bash
node zoo.js auto --keystore ./key.json --once
```

Or step by step: `open` → `mine` → `submit <nonce> [round]` → `claim` →
`reveal [--watch]`. `job [0x…]` prints what a wallet has pending, and the last
round that still takes work mined now. Leave `round` out of `submit` and the CLI
searches the window for the seed that nonce beats.

`status`, `job` and `mine` accept `--json` and print nothing else on stdout —
parse those. Exit `0` fine, `1` failed with the reason on stderr, `2` unknown
command.

## Path B — the open page (`window.PIXELZOO`)

Present on the live site in every tab; see `agent/AGENT.md` for the full surface.
Reads are free, writes open the user's wallet.

```js
const s = PIXELZOO.state();          // mintOpen, price, round, workWindow, difficulty…
let j = PIXELZOO.job();              // seed, targets, pendKind, claimsLeft, goodUntil
if (!j.roundOpen) await PIXELZOO.openRound();
const f = await PIXELZOO.mine({timeoutMs: 600000});
if (f.ok) await PIXELZOO.submitNonce();   // f.nonce, for the round it was mined for
```

Then wait for the ticket to mature (`job().round > job().pendRound`),
`await PIXELZOO.claim()`, and `await PIXELZOO.reveal()`.

## Decide what to do from `job`

| state | do this |
|---|---|
| `claimsLeft == 0` | stop: this wallet has its three pieces |
| `headStartRunning` and `onList == false` | do not mine: every solution would come back `NotOnList`. If `headStartNoEnd` is true it ends when the team ends it — say so and stop, there is nothing to wait out, and the CLI's `mine` returns instead of looping. If it is false, `headStartRounds` is a real countdown and `mine` waits it out |
| `roundOpen == false` | `open` (CLI) or `openRound()` — then re-read |
| `pendKind == 0` (NONE) | mine, then submit |
| `pendKind == 1` (INSTANT) | claim now |
| `pendKind == 2` (TICKET), `round > pendRound` | claim now |
| `pendKind == 2`, `round <= pendRound` | wait one round (~60 s), then claim |

After claiming, call reveal — the queue is permissionless and the user's voucher
is at the back of it.

## When something fails

| error | meaning |
|---|---|
| `WorkExpired` | the solution is older than the work window; mine a fresh one |
| `WorkTooWeak` | the nonce does not beat the target for the round you named |
| `SolutionUsed` | that hash was already spent; mine again |
| `AlreadyHolding` | claim the pending solution before mining another |
| `TicketNotReady` | wait for the next round |
| `WrongPayment` | send exactly `mintPriceWei` |
| `WalletCapReached` | three already, and it does not reset |
| `RoundNotOpen` | that round has no seed: nobody opened it, or it has not happened yet |
| `NothingToReveal` | no draw block has landed yet; wait ~12–24 s |
| `NotOnList` | a whitelist head start is still running and this wallet is not on it. `headStartNoEnd` false → `roundsToPublic()` says for how long; true → until the team says otherwise, and a 78-digit `roundsToPublic` is that sentinel, not a duration |

None of these mean the miner is broken. A mismatch in `verify` does: stop, do not
mine, the keccak disagrees with the contract's.

## Report honestly

Mining is a lottery per hash, not a queue: "about 20 seconds on 15 threads" is an
average, and a run taking five times that is normal. The animal is not decided
when you pay, so do not promise a species or a tier — and do not claim a rarity
until `reveal` has actually landed. A manual head start has no end time: never
invent one, and never turn a 78-digit `roundsToPublic` into minutes.

## Files

Paths inside the downloaded archive, which is also where this file lives:

```
zoo.js                          the miner: verify, status, job, mine, submit, claim, reveal, auto
README.md                       the command line miner in full
agent/AGENT.md                  window.PIXELZOO, method by method
skills/pixelzoo-miner/SKILL.md  this file
pixelzoo.json                   the contract and network it is pointed at
shared/                         the keccak, identical to the browser's and the contract's
```

To install this skill for a local agent, copy the folder into whatever directory
that agent reads its skills from:

```bash
cp -r pixelzoo-miner/skills/pixelzoo-miner <your-agent>/skills/
```

In the repository the same tree is split — `cli/`, `shared/`, `skills/`, `agent/`
side by side — and the archive is built from it by `scripts/pack_cli.mjs`.
